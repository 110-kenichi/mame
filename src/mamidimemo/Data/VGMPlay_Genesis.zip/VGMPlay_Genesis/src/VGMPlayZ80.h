#ifndef _VGMPLAYZ80_H_
#define _VGMPLAYZ80_H_

extern const u8 VGMPlayZ80[0x29F];

#endif // _VGMPLAYZ80_H_

#ifndef _RES_RESOURCES_H_
#define _RES_RESOURCES_H_


#endif // _RES_RESOURCES_H_

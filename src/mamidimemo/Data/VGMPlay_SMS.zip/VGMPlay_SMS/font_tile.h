extern const unsigned char	font_map_bin[];
#define				font_map_bin_size 128

extern const unsigned char	font_pal_bin[];
#define				font_pal_bin_size 16

extern const unsigned char	font_tile_bin[];
#define				font_tile_bin_size 2048


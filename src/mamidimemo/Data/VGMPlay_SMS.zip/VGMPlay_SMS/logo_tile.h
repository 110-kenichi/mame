extern const unsigned char	logo_bg_map_bin[];
extern const unsigned char	logo_bg_map_bin_sp[];
#define				logo_bg_map_bin_size 96

extern const unsigned char	logo_bg_pal_bin[];
#define				logo_bg_pal_bin_size 5

extern const unsigned char	logo_bg_tile_psgcompr[];
#define				logo_bg_tile_psgcompr_size 666

extern const unsigned char	logo_sp_map_bin[];
#define				logo_sp_map_bin_size 512

extern const unsigned char	logo_sp_pal_bin[];
#define				logo_sp_pal_bin_size 6

extern const unsigned char	logo_sp_tile_psgcompr[];
#define				logo_sp_tile_psgcompr_size 307

extern const unsigned char	Wave_pcmenc[];
#define				Wave_pcmenc_size 4826


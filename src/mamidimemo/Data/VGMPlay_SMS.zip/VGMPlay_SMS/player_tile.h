extern const unsigned char	title_psg[];
#define				title_psg_size 489

extern const unsigned char	title_bg_map_bin[];
#define				title_bg_map_bin_size 5632

extern const unsigned char	title_bg_pal_bin[];
#define				title_bg_pal_bin_size 15

extern const unsigned char	title_bg_tile_psgcompr[];
#define				title_bg_tile_psgcompr_size 2580

extern const unsigned char	title_sp_map_bin[];
#define				title_sp_map_bin_size 128

extern const unsigned char	title_sp_pal_bin[];
#define				title_sp_pal_bin_size 15

extern const unsigned char	title_sp_tile_psgcompr[];
#define				title_sp_tile_psgcompr_size 1179


#include <stdlib.h>
#include <math.h>
#include <stdbool.h>

#define CHGMOD      #0x005f
#define CHPUT       #0x00A2
#define CHGET       #0x009F
void print(char * pc) __z88dk_fastcall;
void putchar(char c) __z88dk_fastcall;

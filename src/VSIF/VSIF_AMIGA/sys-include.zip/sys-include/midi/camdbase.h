#ifndef MIDI_CAMDBASE_H
#define MIDI_CAMDBASE_H

#ifndef EXEC_LIBRARIES_H
#include <exec/libraries.h>
#endif

struct CamdBase 
{
	struct Library Lib;
};

#endif
